#import "Core/USUnifiedTransport.h"
// The tour goes up the first time Home appears, not at launch: a fresh sideload lands on the login
// screen first, and a tour over that is wrong. A moment after, so Home has drawn under the glass.
// The tour is the only first-run sheet in this private build.
#import "Core/SGCore.h"
#import "Onboarding.h"

%hook _TtC19Home_FunkisPageImpl20FunkisViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (!SGFlag(SGKeyOnboardingSeen, NO)) SGShowOnboarding();
        });
    });
}
%end

%ctor {
    if (!USUnifiedTargetSupported()) return;
    if (SGFlag(SGKeyOnboardingSeen, NO)) return;
    %init;
    SGRequireClasses(@[@"_TtC19Home_FunkisPageImpl20FunkisViewController"]);
}
